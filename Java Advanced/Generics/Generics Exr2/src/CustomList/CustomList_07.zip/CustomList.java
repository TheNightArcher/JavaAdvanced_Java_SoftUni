package CustomList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomList<T extends Comparable> {
    private List<T> elements;

    public CustomList() {
        this.elements = new ArrayList<>();
    }

    public void add(T element) {
        this.elements.add(element);
    }

    public void remove(int element) {
        this.elements.remove(element);
    }

    public boolean contains(T element) {
        if (elements.contains(element)) {
            return true;
        }
        return false;
    }

    public void swap(int first, int second) {
        Collections.swap(elements, first, second);
    }

    public int greater(T element) {
        return (int) this.elements.stream().filter(e -> e.compareTo(element) > 0).count();
    }

    public void max() {
        System.out.println(Collections.max(elements));
    }

    public void min() {
        System.out.println(Collections.min(elements));
    }

    public void forEach(){
        elements.forEach(System.out::println);
    }


}