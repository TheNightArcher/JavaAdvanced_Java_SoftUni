package GenericBox;

public class Box<T> {

    private T elements;

    public Box(T element) {
        this.elements = element;
    }

    @Override
    public String toString() {

        return String.format("%s: %s",elements.getClass().getName(),elements);
    }
}
